'use strict';
// Android 替代实现：原生 node-addon-require-builtin 依赖 glibc 预编译 .node，
// 在 bionic 上无法加载。dsh 只在 --expose-internals 下用它取 internal/* 模块，
// 这里直接用 createRequire 转发，等价于 node:internal 的原生访问。
const { createRequire } = require('node:module');
const req = createRequire(__filename);
function requireBuiltin(id) { return req(id); }
function isAllowedInternalId(id) {
  return typeof id === 'string' && id.startsWith('internal/');
}
function getBindingInfo() {
  return { variant: 'android-js-stub', builtinPrefix: 'internal/' };
}
module.exports = { requireBuiltin, isAllowedInternalId, getBindingInfo };
module.exports.default = module.exports;
