# dshtool Android arm64 原生依赖审计

- DSH 版本：0.2.2-rc.1（与宿主安装 `/usr/lib/node_modules/@deepseek-ai/dsh` 一致）
- 目标平台：Android arm64-v8a，bionic libc，API 24+，无 root
- Node：26.13.1，以 `--dest-os=android` 交叉编译，`process.platform === "android"`、`process.arch === "arm64"`
- 构建机：aarch64 Linux + Android NDK r27c，`packaging/build-android-native.sh` 产出 Android 原生件
- 产物：`dist/dshtool-android-arm64.tar.gz`（含 `bin/node`）、`dist/dshtool-assets.zip`（APK assets，不含 `bin/node`，APK 侧用 `nativeLibraryDir/libnode.so`）

## 1. 结论摘要

DSH 的原生依赖可以分成四类处理：

| 类别 | 模块 | 处理 |
| --- | --- | --- |
| 启动/持久化必需 | `@deepseek-ai/node-addon-system`（flock） | **NDK 重编**，并适配 `process.platform === "android"` |
| 可选能力 | `landlock-run`、`node-pty` | **NDK 重编**；平台/权限缺失时优雅降级 |
| 仅 Windows / 实验功能 | `koffi`、`sherpa-onnx-node` | **删除预编译件 + 抛错桩**（保持 JS 包名与 API） |
| 图像 / 搜索 | `sharp`、`@vscode/ripgrep` | **删除 glibc 预编译件**；sharp 用桩，ripgrep 无 Android 预编译，grep/fs-search 工具降级 |

最终包内只允许存在两个 `.node`：

1. `node-pty/build/Release/pty.node`（NDK，Android 24）
2. `@deepseek-ai/node-addon-system-android-arm64/bin/musl/system.node`（NDK，flock）

JS 层已在宿主 Linux 用 Node 26 验证：`bin/dshtool --version` → `0.2.2-rc.1`，`dsh web` 可启动并返回 HTTP 302/303 登录跳转。Android/bionic 上的真实启动（qemu 或真机）待 `bin/node` 就绪后由 verifier 执行。

## 2. 运行时假设

- 设备提供 `/system/bin/sh`、`/system/bin/linker64`；**没有** `/bin/sh`，因此包内脚本 shebang 统一为 `#!/system/bin/sh`。
- Node 启动参数必须包含 `--expose-internals`（见 4.3），`bin/dshtool` 已固定传入；直接调用 `bin/node lib/node_modules/@deepseek-ai/dsh/lib/bin.js` 时必须自行加上。
- `DSH_HOME` 必须可写：`bin/dshtool` 默认使用包内 `dsh-home/`（解压目录需可写），也可用 `DSH_HOME=/path` 覆盖。APK 侧应指向 `filesDir`。
- node-pty 只在终端功能（`terminal-*`）里懒加载；普通 `bash` 工具走 `child_process`，不依赖 node-pty。

## 3. 原生模块逐项清单

| 模块 / 文件 | 加载点 | 作用 | Android 处理 | 不可用后果 |
| --- | --- | --- | --- | --- |
| `@deepseek-ai/node-addon-system` | `dsh-session-persistence-jsonl/lib/index.js:12`（顶层 import） | 会话文件写租约 `flock(2)` | NDK 重编 `src/flock.c`；`flock.js` 接受 `android`；平台包 `@deepseek-ai/node-addon-system-android-arm64` | session 写租约获取失败，持久化启动阶段报错 |
| `landlock-run`（node-addon-system） | `dsh-sandbox-local/lib/index.js:6` | Landlock 沙箱启动器 | NDK 重编 `src/main.c`，放入 Android 平台包；`PLATFORM_CHAINS.android = ["landlock"]` | 探针 `unusable`；默认 `danger-full-access` 下 bash 仍可用 |
| `node-addon-require-builtin` | `dsh-app-boot/lib/index.js:2565-2571`（无 try/catch） | 读取 Node internal ESM/CJS loader | 删除 gnu/musl 预编译件与 custom-loader；用 JS 桩 + `--expose-internals` | profile/runtime 注入失败，web 起不来 |
| `node-pty` | `dsh-subprocess-local/lib/index.js:1442`（lazy） | 伪终端 | 使用 Android 版 `pty.node`；NDK 重编 `spawn-helper` | 终端工具启动失败；其它功能不受影响 |
| `sharp` + `@img/sharp-*` | `dsh-attachment-local/lib/index.js:118`（lazy） | 图像元数据/缩放/编码 | 删除；`sharp` 换成抛 `ERR_DSHTOOL_FEATURE_UNAVAILABLE` 的桩 | 图片附件元数据/缩略图功能失败 |
| `koffi` | 仅 Win32 分支（`dsh-fs-local`、`dsh-session-persistence-jsonl` 等） | Windows FFI | 删除；桩 | Android 正常路径不加载，无影响 |
| `sherpa-onnx-node` / `sherpa-onnx-linux-arm64` | `dsh-experimental-speech-to-text-sensevoice/lib/worker.js` | 本地语音识别 | 删除；桩 | 该实验插件不可用，不在 web profile 默认组合中 |
| `@vscode/ripgrep-linux-arm64` | `dsh-tool-fs-search/lib/index.js:119-128` | grep/文件搜索 | 删除（无 android 平台包，glibc 二进制无法在 bionic 执行） | `grep` / fs-search 工具调用报 `SEARCH_FAILED`；其它工具正常 |
| `libreoffice-kit-wasm` | office-to-pdf / office 插件 | Wasm 版 LibreOffice | 保留 | 可用但内存占用高，低内存设备可能 OOM |
| 其它平台预编译（`node-pty/prebuilds`、`node-addon-system-linux-arm64` 等） | — | — | 删除 | — |

## 4. 关键处理细节

### 4.1 flock（启动必需）

`dsh-session-persistence-jsonl` 在模块顶层 import `@deepseek-ai/node-addon-system/flock`；`SessionWriteLease.acquire()` 以 `open(path, "w")` 打开租约文件后 `await tryLockExclusive(handle.fd)`，非竞争类错误会直接抛出。因此 Android 上必须让这个 N-API 插件可加载。

`flock.js` 原实现：

```js
if (platform !== 'linux' && platform !== 'darwin') throw ERR_FLOCK_UNSUPPORTED_PLATFORM;
if (platform === 'linux') {
  const report = process.report.getReport();
  filename = join(report.header.glibcVersionRuntime ? 'glibc' : 'musl', filename);
}
```

Android 的 `platform` 是 `"android"`，且 bionic 没有 `glibcVersionRuntime`，`process.report` 的 libc 字段也不可靠。补丁后：

```js
if (platform !== 'linux' && platform !== 'darwin' && platform !== 'android') { ... }
if (platform === 'android') {
  filename = join('musl', filename);        // 不调用 process.report
} else if (platform === 'linux') {
  const report = process.report.getReport();
  filename = join(report.header.glibcVersionRuntime ? 'glibc' : 'musl', filename);
}
```

平台包布局（相对 `dsh/node_modules/@deepseek-ai/`）：

```
node-addon-system-android-arm64/
  package.json                     os: ["android"], cpu: ["arm64"]
  bin/musl/system.node             N-API v8，flock(2)，ELF aarch64 Android 24
  bin/landlock-run                 PIE，interpreter /system/bin/linker64
```

`src/flock.c` 直接调用 bionic 的 `flock()`（NDK r27c sysroot 的 `sys/file.h` 有声明），N-API 异步执行；`NEEDED` 仅 `libdl.so`、`libc.so`，不依赖 `libc++_shared`。

残余风险：

- `flock()` 在部分 FUSE/共享存储（如 `/sdcard`）上可能返回 `ENOTSUP`/`EOPNOTSUPP`。**`DSH_HOME` 应放在应用内部存储或可写 ext4 分区**，不要放在 `/sdcard`，否则写租约可能失败。
- Android 内核（API 24 起）均支持 BSD `flock`，但非常旧的定制内核或 32 位兼容层未验证；qemu/真机冒烟会覆盖。
- APK 场景若 `filesDir` 中的 `.node` 无法 dlopen，可把 `system.node` 以 `libsystemnode.so` 放进 `nativeLibraryDir`，并设置 `DSHTOOL_SYSTEM_NODE=<绝对路径>`；`flock.js` 用 `process.dlopen()` 加载（`.node` 仍走 `require`）。

**SELinux 硬链接限制（真机发现，必须保留补丁）**：Android 10+ 的 `untrusted_app` 域禁止对应用数据目录的 `app_data_file` 调用 `link(2)`（内核日志 `avc: denied { link }`，Node 侧 `EACCES`）。`dsh-session-persistence-jsonl` 的 `materializePosix()` 与 `publishCurrentExclusive()` 原本用 `link(tmp, final)` 做原子发布，导致**新建会话落盘失败**，UI 显示“本轮运行失败 EACCES”。

`build-bundle.sh` 在打包时把两处 `link()` 替换为注入的 `publishLinkedOrRenamed(from, to)`：

- 先尝试 `link(from, to)`；
- 仅当错误码为 `EACCES` / `EPERM` / `ENOSYS` / `EXDEV` 时降级：`lstat(to)` 必须为 `ENOENT`（目标已存在则抛 `EEXIST`），随后 `rename(from, to)`；
- 其它错误原样抛出，不掩盖真实故障。

同一文件系统内 `rename` 是原子的，且保留“目标不存在才发布”的单进程语义；多进程并发发布时 create-exclusive 退化为先到先得，DSH 侧还有会话写租约 `flock` 兜底。补丁若丢失，Android 真机新建会话会再次失败。

### 4.2 Landlock

`dsh-sandbox-local` 用 `launcherPath()` 解析 `@deepseek-ai/node-addon-system-${platform}-${arch}/bin/landlock-run`，并 `spawnSync ... --probe` 判断可用性。Android 平台包已提供 NDK 版启动器；`PLATFORM_CHAINS` 增加：

```js
android: ["landlock"]
```

若内核未开启 Landlock（或 SELinux 禁止相关 syscall），probe 失败 → 该平台链判定 `unavailable`。默认权限模式已改为 `danger-full-access`，因此不会 fail closed；但**如果用户显式设置 `DSH_PERMISSION_MODE=workspace-write` 且 Landlock 不可用，bash 工具会因 `SandboxUnavailableError` 拒绝执行**。这是有意的 fail-closed 行为。

安全边界：Android 上没有 bwrap/seatbelt 等价物，DSH 层默认不做文件系统沙箱；实际隔离依赖 Android 应用沙箱、SELinux 与应用权限。该降级已写入 `dsh-base/cordis.patch.yml` 的平台条件表达式，Linux/macOS/Windows 行为不变。

### 4.3 require-builtin（启动必需）

`dsh-app-boot/lib/index.js:2565` 的 `internalModules()` 直接 `createRequire(import.meta.url)("node-addon-require-builtin")`，没有 try/catch；失败会阻止 profile 加载。`dsh-hmr` 和 `cordis-plugin-loader` 有 try/catch 回退，但主路径必须成功。

处理：

- 删除 `node-addon-require-builtin-linux-arm64-{gnu,musl}` 与 `node-addon-native-custom-loader`；
- 用 `packaging/stub-require-builtin.js` 覆盖包入口，保持 `requireBuiltin(id)` / `isAllowedInternalId` / `getBindingInfo` / default 导出等 API；
- `bin/dshtool` 固定以 `--expose-internals` 启动 Node（该 flag 不能通过 `NODE_OPTIONS` 传入，必须作为命令行参数）。

桩实现核心：

```js
const require = createRequire(__filename);
function requireBuiltin(id) {
  if (!isAllowedInternalId(id)) throw ...;
  return require(id);
}
```

宿主验证（Node 26 + `--expose-internals`）：`internal/modules/esm/loader`、`internal/modules/cjs/loader` 等 5 个模块可加载，分别得到 `getOrInitializeCascadedLoader`、`Module._resolveFilename` 等函数。`internal/bootstrap/realm` 不可 require，但仅 HMR 路径使用，已有回退。

### 4.4 node-pty

`dsh-subprocess-local` 只在终端功能中 lazy require。Android 版 `pty.node` 由 NDK r27c 编译（`aarch64-linux-android24`），`NEEDED` 为 `libm.so`、`libdl.so`、`libc.so`。

`node-pty/lib/unixTerminal.js` 还需要同目录的 `spawn-helper`（`binding.gyp` 的 `spawn-helper` target，源码 `src/unix/spawn-helper.cc`）。本包已用 NDK 编译并放在 `build/Release/spawn-helper`。

APK 特别注意：Android 10+ 默认禁止从应用 `filesDir` 执行文件，而 `pty.fork` 需要 exec `spawn-helper`。处理：

- CLI/tar 安装（解压目录可执行）直接可用；
- APK 侧应把 `spawn-helper` 放入 `nativeLibraryDir`（或可执行目录），并通过环境变量覆盖：

```js
if (process.env.DSHTOOL_PTY_HELPER) helperPath = process.env.DSHTOOL_PTY_HELPER;
```

残余风险：部分厂商 ROM 对 `nativeLibraryDir` 的 exec 或 `forkpty` 有额外限制；终端功能失败时只影响 `terminal-*` 工具。

### 4.4.1 APK 的 nativeLibraryDir 方案

APK 安装器只解压 `lib/<abi>/lib*.so`；Android 10+ 对应用 `filesDir` 的执行/加载限制因 ROM 而异。为 APK 预留以下接口（CLI/tar 安装不需要）：

| 文件（dist/dshtool-native-libs/） | 来源 | 环境变量（绝对路径） | 用途 |
| --- | --- | --- | --- |
| `libspawn_helper.so` | NDK `spawn-helper` | `DSHTOOL_PTY_HELPER` | 终端 fork 的 exec 目标（只 exec，不 dlopen） |
| `libnodepty.so` | NDK `pty.node` | `DSHTOOL_PTY_NODE` | node-pty 原生 addon |
| `libsystemnode.so` | NDK `system.node` | `DSHTOOL_SYSTEM_NODE` | flock 原生 addon（启动必需） |

约定：

- 三个变量都接受**完整文件路径**（含 `lib*.so` 文件名），JS 侧不做目录拼接；
- `DSHTOOL_PTY_HELPER` 在 `node-pty/lib/unixTerminal.js` 覆盖 `helperPath`；
- `pty.node` / `system.node` 的 env 路径由新增的 `loadAddonExplicit()` / `loadAddon()` 加载：`.node` 走 `require`，`.so` 走 `new Module(path)` + `process.dlopen(mod, path)`。宿主机实测 `require('./libpty.so')` 会报 `Invalid or unexpected token`，`process.dlopen` 可正常返回 `fork/open/resize/process`；
- 不设置变量时行为不变：node-pty 用包内 `build/Release`，flock 用 Android 平台包；
- `PTY_NODE`/`SYSTEM_NODE` 是可选降级开关：web 启动不加载 pty，只有终端操作才需要；flock 启动必需，若 APK 内 `filesDir` 的 `.node` 加载失败再切 `DSHTOOL_SYSTEM_NODE`。

### 4.5 sharp

唯一运行时调用点是 `dsh-attachment-local/lib/index.js:118` 的 lazy `requireSharp`。`@img/sharp-linux-arm64` 与 libvips 预编译 `.so` 是 glibc 链接，bionic 无法加载，无法通过简单重编在包内解决（libvips 依赖链大）。

处理：删除 `@img/`、`sharp/`，安装同名桩包：

```js
throw Object.assign(new Error("sharp is not available in the dshtool Android build"), {
  code: "ERR_DSHTOOL_FEATURE_UNAVAILABLE",
});
```

影响：图片附件的元数据探测、缩放/缩略图、格式转换失败；文本/代码类附件与核心会话不受影响。后续如需要，可改为纯 JS 探测（读 PNG/JPEG 头）或接入 Android 原生解码。

### 4.6 koffi

所有动态 import 都在 Win32 分支（`process.platform === "win32"` / `kernel32.dll` / `advapi32.dll`），Android 正常路径永不加载。处理：删除 `@koromix/` + `koffi/`，桩抛错，防止意外路径把 glibc `.node` 带进来。

### 4.7 sherpa-onnx

仅 `dsh-experimental-speech-to-text-sensevoice` 的 worker 使用，默认 web profile 不含该插件。删除 `sherpa-onnx-linux-arm64`（含 34.6MB `libonnxruntime.so`）与 `sherpa-onnx-node`，桩保持包名。本地语音识别不可用；如需启用，需要为 Android 重编 onnxruntime + sherpa-onnx。

### 4.8 ripgrep / fs-search

`dsh-tool-fs-search` 通过 `@vscode/ripgrep` 解析平台包；其平台包命名不含 `android`，且 `@vscode/ripgrep-linux-arm64/bin/rg` 是 glibc 动态 ELF，在 bionic 上无法执行。处理：删除该目录；调用 `grep`/fs-search 工具时返回 `SEARCH_FAILED`。

替代方案（未实现）：为 Android 交叉编译 ripgrep 并替换 `@vscode/ripgrep` 的 `rgPath`，或改用纯 JS 搜索。该降级只影响搜索工具，不影响读写/bash。

### 4.9 libreoffice-kit-wasm

`soffice.wasm`（127.8MB）是 WebAssembly，不依赖 bionic ELF，V8 可直接执行，因此保留。风险是运行时内存（数百 MB 到 GB 级），低内存设备可能 OOM；office→pdf 属于可选功能，失败应作为工具错误返回。

### 4.10 pnpm（插件市场必需）

`dsh-plugin-manager` 硬编码调用 `pnpm view` / `pnpm add`。早期包内只有 npm/npx，真机打开插件页直接 `spawn pnpm ENOENT`。处理：

- 包内加入 pnpm 10.18.3（解包约 21MB，tgz 4.0MB）到 `lib/node_modules/pnpm/`，保留 `bin/pnpm.cjs`、`bin/pnpx.cjs`、`dist/pnpm.cjs` 与 `dist/node_modules/**`；
- 生成 `bin/pnpm`、`bin/pnpx` 包装器（`#!/system/bin/sh`，用同目录 `bin/node` 执行对应 cjs）；
- pnpm 默认用 hardlink 建立 store，而 Android `untrusted_app` 域对应用数据目录禁止 `link(2)`（同 4.1 的 SELinux 限制）。因此包根写入 `.npmrc`：`package-import-method=copy`，并由 `bin/dshtool` 导出 `NPM_CONFIG_USERCONFIG=${NPM_CONFIG_USERCONFIG:-$ROOT/.npmrc}`（用户显式设置时不覆盖；APK 侧另写 `HOME/.npmrc`，两者不冲突）；
- 验证用 qemu node 直跑 `lib/node_modules/pnpm/dist/pnpm.cjs --version` → `10.18.3`；**不要**在 qemu-user 下执行 `sh bin/pnpm`（嵌套 exec 找不到 `/system/bin/linker64`）。

**noexec 第二层（真机发现）**：APK 把 assets 放在 `filesDir`，Android 10+ 禁止从该目录 `exec`，因此插件管理器即使拿到 `bin/pnpm` 也无法直接 spawn；pnpm 内部回退执行 `npm` 时同样会踩到。打包时做两处补丁：

- `dsh-plugin-manager/lib/index.js`：`pnpmExeca()` 把 `execa("pnpm", …)` 改为用 `DSHTOOL_NODE || process.execPath` 执行包内 `lib/node_modules/pnpm/bin/pnpm.cjs`（可用 `DSHTOOL_PNPM_CJS` 覆盖路径）；
- `pnpm/dist/pnpm.cjs`：`packaging/patch-pnpm-npm.py` 把 `runNpm()` 的 `"npm"` 改为 `DSHTOOL_NODE || process.execPath` + 包内 `lib/node_modules/npm/bin/npm-cli.js`（可用 `DSHTOOL_NPM_CLI` 覆盖），并在补丁后断言无残留 `spawn("npm")` / `execa("npm")`。

两层都走 node 直跑 JS，不依赖 `bin/pnpm`、`bin/npm` 的可执行位。

**noexec 第三层（通用兜底）**：为了覆盖 DSH/插件生态里仍以裸命令名调用包管理器（`spawn("npm")`、`exec("pnpm view …")` 等）的路径，包内新增 `bin/dshtool-noexec-shim.cjs`，由 `bin/dshtool` 通过 `NODE_OPTIONS="--require $ROOT/bin/dshtool-noexec-shim.cjs"` 预载：

- patch `child_process` 的 `spawn`/`spawnSync`/`execFile`/`execFileSync`/`exec`/`execSync`；
- 仅当命令 basename 为 `npm|npx|pnpm|pnpx|corepack` 且是**非绝对路径**时，改写为 `[process.execPath, <包内 cli>]`（npm-cli.js / npx-cli.js / pnpm.cjs / pnpx.cjs / corepack.js）；绝对路径与未知命令原样放行；
- 根目录取 `DSHTOOL_ROOT`，否则 shim 所在 `bin/` 的上一级；每个进程只 patch 一次，并设置 `DSHTOOL_NOEXEC_SHIM=1` 便于诊断；
- qemu bionic node 已验证 `spawn("npm"/"npx"/"pnpm", ["--version"])` 与 `execSync("npm --version")` 均返回正确版本。qemu-user 不能嵌套 exec 本机 bionic 二进制，故测试时把 `process.execPath` 指向宿主 node 以隔离验证 shim 重写逻辑；真机 `process.execPath` 即 node 本体，无需覆盖。

旧发行包（tar `7d36e7e5…`、assets `050c166c…`）只有前两层；加入第三层后重新打包，sha 见 `docs/TEST-REPORT.md` 与发布记录。

残余风险：copy 模式比 hardlink 占用更多磁盘，pnpm store 会增长在 `DSH_HOME` 所在分区；低存储设备需提示用户清理。

### 4.11 bash → /system/bin/sh（Android 无 bash）

DSH 的 `dsh-bash-local` 与 `dsh-bash-sandbox` 在 argv 中硬编码 `"bash", "-c"`；Android 没有 bash，即使是 `dsh` 的 bash 工具也会直接 ENOENT。处理：

- `packaging/patch-bash-sh.py` 幂等替换这两个插件里的精确 argv 对，改为 `"/system/bin/sh", "-c"`，插入标记 `[dshtool] bash via /system/bin/sh`；
- 只匹配 `"bash"` + `"-c"` 的 argv 组合，不替换权限/工具名等其它 `"bash"` 字面量（如 `dsh-experimental-liveshare` 的 deniedCapabilities）；
- 替换后断言每个文件有标记、残留 `"bash",` 为 0、无未替换的 bash -c 对；`build-bundle.sh` 在打包时调用；
- `dshtool-noexec-shim.cjs` 增加防御：任何 `spawn`/`exec`/`spawnSync` 的命令为 `bash` 或路径以 `/bash` 结尾时，改写为 `/system/bin/sh`。
- 终端插件 `dsh-terminal-bash/lib/index.js` 的默认值同样硬编码 bash：`DEFAULT_BASH_SHELL = "/bin/bash"`、`DEFAULT_BASH_ARGS = ["--noprofile","--norc","-i"]`（mksh 不认这两个参数）。补丁改为 `DEFAULT_BASH_SHELL = "/system/bin/sh"`、`DEFAULT_BASH_ARGS = ["-i"]`，标记 `[dshtool] terminal via /system/bin/sh`；覆盖持久终端与 `persistent-bash` 工具（`dsh-tool-bash-persistent` 复用同一 PTY 后端默认值）。`config.shellPath`/`shellArgs` 显式配置仍可覆盖。

验证：宿主用 shim 的导出函数检查 `["bash","-c","echo hi"] → ["/system/bin/sh","-c","echo hi"]`、`"/bin/bash" → "/system/bin/sh"`，`spawn("bash")` 的错误路径为 `/system/bin/sh`；qemu 下用 `sh -c` 执行同一命令通过。残余风险：bash 专有语法（数组、`[[ ]]`、`source` 等）在 mksh 下可能不兼容，工具描述仍写 bash，属已知降级。

### 4.12 自动更新、androidize 与 release 签名

- **原地更新**：`bin/dsh-update.js` 对三个 npm 源测速（`registry.npmjs.org`、
  `registry.npmmirror.com`、`mirrors.cloud.tencent.com/npm`，可用
  `DSHTOOL_UPDATE_SOURCES` 覆盖），按最快源把 `@deepseek-ai/dsh@<version>` 装到
  `<root>/versions/<version>/lib/node_modules/@deepseek-ai/dsh`，然后调用
  `sh <root>/bin/androidize-install.sh <dir> <root>` 重放本文件所有 Android 补丁，
  再以 `node <pkg>/lib/bin.js --version` 冒烟，全部通过才原子写 `active.json`。
  退出码：0 成功 / 10 全部源不可达 / 11 安装失败 / 12 校验失败。
- **androidize 可复用**：`packaging/overlay/bin/androidize-install.cjs` 是唯一
  Android 化实现（CJS，无 python/bash 依赖），build-bundle 与 updater 共用。
  接口 `androidize-install.sh <prefix> [<base-bundle-root>]`，幂等；base 用于取
  pty.node/spawn-helper/system.node/landlock-run/require-builtin 桩/npm/pnpm/
  noexec shim，也可分别用 `DSHTOOL_PTY_NODE_SRC`、`DSHTOOL_PTY_HELPER_SRC`、
  `DSHTOOL_SYSTEM_NODE_SRC`、`DSHTOOL_LANDLOCK_SRC`、`DSHTOOL_REQUIRE_STUB`、
  `DSHTOOL_SHIM_SRC`、`DSHTOOL_NPM_SRC`、`DSHTOOL_PNPM_SRC` 覆盖，
  `DSHTOOL_COPY_TREES=1` 强制复制 npm/pnpm 树而不是 symlink。
- **启动切换**：`bin/dshtool` 先校验 `active.json` 的 `dir` 下是否存在
  `lib/node_modules/@deepseek-ai/dsh/lib/bin.js`，存在则执行该版本的 `lib/bin.js`；
  文件缺失、JSON 损坏或目标被删时静默回退包内版本。`--rollback` 通过
  `active.prev.json` 回退。
- **release 签名**：`packaging/release-sign.sh <unsigned.apk> <out.apk>` 用 apksigner
  签 v2+v3（v1 关闭，minSdk 24），并 `verify --print-certs`；keystore 默认
  `packaging/release/dshtool-release.keystore`（alias `dshtool`，口令
  `dshtool-release`，仅供测试），可用 `DSHTOOL_KS`/`DSHTOOL_KS_PASS`/
  `DSHTOOL_KEY_ALIAS` 覆盖；口令走 `env:` 不进入 argv。包内副本位于
  `share/doc/dshtool/release/`。
- **noexec 三层防御**：wrapper 无 exec 位（第一层）→ 包内 launcher 预载
  `dshtool-noexec-shim.cjs`，把 npm/npx/pnpm/pnpx/corepack/bash 子进程改写为
  `[node, 包内 cli]`（第二层）→ updater 安装后跑 androidize，确保新版本同样
  带 shim 与补丁（第三层）。

## 5. `process.platform === "android"` 适配汇总

| 位置 | 原行为 | Android 补丁 |
| --- | --- | --- |
| `node-addon-system/lib/flock.js` | 只接受 linux/darwin；按 `process.report` 选 glibc/musl | 接受 android；android 固定 `musl/system.node`，不调用 report |
| `node-addon-system/lib/index.js` | 平台包 `...-${platform}-${arch}` | 包已按 `android-arm64` 命名提供 |
| `dsh-sandbox-local/lib/index.js` | `PLATFORM_CHAINS` 无 android → `[]` → 抛 `SandboxUnavailableError` | 增加 `android: ["landlock"]` |
| `dsh-base/cordis.patch.yml` 权限默认 | `workspace-write` / `ask` | android 默认 `danger-full-access` / `never`，可用 `DSH_PERMISSION_MODE` 覆盖 |
| `dsh-tool-fs-search` | 依赖 @vscode/ripgrep 平台包 | 无 Android 包，工具级降级（未打补丁） |

YAML 注意：`!!js` 后面的表达式含 `:`（三元表达式）时必须整体加双引号，否则 js-yaml 解析为 mapping 并报：

```
YAMLException: bad indentation of a mapping entry (246:129)
```

表现为 `dsh: skipping profile bundle "@deepseek-ai/dsh-base"`，web 启动失败。当前写法：

```yaml
mode: !!js "process.env.DSH_PERMISSION_MODE ?? (process.platform === 'android' ? 'danger-full-access' : 'workspace-write')"
```

## 6. 体积

| 项 | 大小 |
| --- | --- |
| 宿主 DSH 安装树 | 924 MB / 69,456 文件 |
| 裁剪后 `packaging/dshtool` | 472 MB（无 `bin/node`） |
| `dist/dshtool-android-arm64.tar.gz` | 95 MB（无 node，最终包另计） |
| `dist/dshtool-assets.zip` | 116 MB（无 `bin/node`、无 `dsh-home`） |
| `dist/dshtool-native-libs/` | 约 650 KB（libnodepty/libsystemnode/libspawn_helper） |
| 删除项 | `@img` 19MB、`koffi` 2MB、`sherpa-onnx-linux-arm64` 39MB、`node-pty` 预编译 26MB、ripgrep 4.6MB、require-builtin gnu 428KB、custom-loader 52KB、node-addon-system-linux-arm64 252KB |

裁剪同时去掉 `*.map`、`*.ts`、`*.mts`、`*.cts`、`*.pdb`、`*.exe`、`*.dll`、`*.dylib`、`*.lib` 等非运行文件。

## 7. 验证

### 宿主 JS 层（已通过）

```sh
cd packaging/dshtool
DSH_HOME=$PWD/dsh-home DSHTOOL_NODE=$(command -v node) sh ./bin/dshtool --version
# 0.2.2-rc.1

DSH_HOME=$PWD/dsh-home DSHTOOL_NODE=$(command -v node) sh ./bin/dshtool web --host 127.0.0.1 --port 0 --no-open
# stdout: dsh web: http://127.0.0.1:<port>/?token=...
# HTTP 302/303 登录跳转视为可用
```

注意：`bin/dshtool` 的 shebang 是 `#!/system/bin/sh`（Android 专用），宿主 Linux 上请用 `sh bin/dshtool` 调用。

### Android/bionic（待 node 就绪）

```sh
# 结构/版本
tar tzf dist/dshtool-android-arm64.tar.gz | head
readelf -l dist/node-android-arm64/bin/node | grep interpreter   # /system/bin/linker64
readelf -d .../bin/node | grep NEEDED                            # 不应出现 libc.so.6 等 glibc 库

# qemu 冒烟（verifier）
qemu-aarch64-static -L <bionic-sysroot> ./bin/node --expose-internals \
  lib/node_modules/@deepseek-ai/dsh/lib/bin.js --version
```

包内断言（`build-bundle.sh` 自动执行）：

- `@deepseek-ai/dsh/package.json` 版本必须等于宿主 `0.2.2-rc.1`；
- `bin/dshtool`、`install.sh`、`bin/npm`、`bin/npx` 首行为 `#!/system/bin/sh`；
- 仅保留两个白名单 `.node`。

## 8. 残余风险与后续

1. **真机已部分验证**：Tauri APK 在 Android 16/arm64 真机启动，`libnode.so` + DSH Web UI 正常（token 303 / 无 token 401）；qemu-bionic 冒烟 PASS=14。真机新建会话曾因 SELinux 拒绝 `link(2)` 失败，已用上述 `link→rename` 补丁修复，最终 tar/assets 重打后需再回归一次会话写入。
2. **flock 于 FUSE/共享存储**：`ENOTSUP` 会导致会话租约失败；文档要求 `DSH_HOME` 放内部存储。
3. **Landlock 内核支持不确定**：默认 `danger-full-access` 规避 fail-closed；安全隔离依赖 Android 应用沙箱。显式 `workspace-write` 在无 Landlock 设备上会拒绝 bash。
4. **ripgrep 缺失**：grep/fs-search 工具报错；可后续交叉编译或换纯 JS 实现。
5. **sharp 缺失**：图片附件元数据/缩略图不可用；可后续做纯 JS 头解析。
6. **APK exec/dlopen 限制**：`spawn-helper` 需放入 `nativeLibraryDir` 并设 `DSHTOOL_PTY_HELPER`；若 `filesDir` 的 `.node` 无法 dlopen，用 `DSHTOOL_PTY_NODE`/`DSHTOOL_SYSTEM_NODE` 指向 `nativeLibraryDir/lib*.so`。`filesDir` 能否 dlopen 依赖 ROM，需真机验证。
7. **npm/npx/pnpm**：`bin/npm`、`bin/npx` 由 node-builder 的 npm 树生成，`bin/pnpm`/`bin/pnpx` 来自 pnpm 10.18.3 包；`dsh plugin` 依赖 pnpm（copy 模式，见 4.10）。
8. **体积/启动**：472MB 树（tar 约 126MiB + node）首次解压与启动有一定 IO 成本；libreoffice wasm 首次使用内存峰值高。
9. **更新期磁盘峰值**：每次更新在 `versions/<v>` 保留完整一份 DSH（约 300MB 解压），建议只保留当前+上一版，旧版由 updater/用户清理；APK 内部存储不足时更新会失败并保留旧版。
10. **更新源可用性**：三个镜像都可能被网络/代理拦截；全部不可达时 `--auto` 退出 10。Bootstrap 包没有内置 DSH，无网时启动器会明确报错退出（78/10），不会静默回退。
11. **release keystore 仅为测试**：仓库内 keystore 口令公开，任何正式分发必须替换为自己的 keystore（见 4.12），否则可被伪造升级包。

## 9. Bootstrap 模式（APK 不内置 DSH）

- `bash packaging/build-bundle.sh --bootstrap` 产出 `packaging/dshtool-bootstrap/`、`dist/dshtool-bootstrap-arm64.tar.gz`、`dist/dshtool-bootstrap-assets.zip`；底座只含 node、libc++_shared、npm/npx/pnpm/pnpx、`dsh-update.js`、androidize、noexec shim、`bin/dsh`/`dshtool`，**不含** `@deepseek-ai/dsh`。
- 原生件放在 `share/dshtool/native/{pty.node,spawn-helper,system.node,landlock-run,require-stub.js}`；versions/<v> 安装后 androidize 从该目录取件（`BOOT_NATIVE` 回退），基座无 DSH 也能 Android 化。
- 启动器契约：`DSHTOOL_VERSION_PROBE=1` 输出 `active=<v|none>` 与 `runtime=<实际 package.json.version|error:...>` 后退出；active 缺失/损坏时自动执行 `dsh-update.js --bootstrap`，完成后重读 active；**任何情况下不回退内置 DSH**；正常启动 stderr 打印 `active.version=<v> runtime=<v>`。
- 安装成功后 updater `--cleanup` 删除非 active 旧版本（保留 active+previous）、`versions/.npm-cache` 与临时目录；androidize 顺带 prune 掉 `*.ts/*.map/*.pdb` 与其它平台 prebuilds。实测 rc.5：安装后 768MB → cleanup 后 **545MB**（目标 <600MB）。
- 版本目录内 npm/pnpm 树用相对 symlink 指回基座，避免每个版本重复 42MB；Android 10+ 的 SELinux 只限制 exec，读取 symlink 正常。

## 10. 复现

```sh
# 1) NDK 原生件（flock/landlock/spawn-helper）
bash packaging/build-android-native.sh

# 2) 组装树 + tar/assets（node 就绪后加 --with-node）
bash packaging/build-bundle.sh --with-node

# 3) 宿主冒烟
sh tests/host-smoke.sh   # 若脚本仍直接执行 bin/dshtool，请改为 sh $BUNDLE/bin/dshtool
```

脚本只读宿主 DSH 安装，写 `packaging/` 与 `dist/dshtool*`。
