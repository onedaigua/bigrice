# dshtool release 签名

`packaging/release/dshtool-release.keystore` 是仓库内置的**发布测试 keystore**
（自签名，CN=dshtool，RSA 2048，有效期 10000 天）。正式上架请替换为自己的
keystore，并通过环境变量传入：

```sh
DSHTOOL_KS=/path/to/your.keystore \
DSHTOOL_KS_PASS=*** DSHTOOL_KEY_ALIAS=youralias \
bash packaging/release-sign.sh app/dist/app-unsigned.apk app/dist/dshtool-release.apk
```

- 默认 alias：`dshtool`；默认口令：`dshtool-release`。
- 签名算法：apksigner v2 + v3（v1 关闭，minSdk 24 不需要）。
- apksigner 探测顺序：`$APKSIGNER` → `$ANDROID_BUILD_TOOLS/apksigner` →
  `PATH` → `<repo>/.work/tooling/sdk/build-tools/*/apksigner` → `~/Android/Sdk/...`。
- 口令通过 `env:DSHTOOL_KS_PASS` 传递，不进入命令行/进程名。
- 成功返回 0 并写出 `<out.apk>`；失败非零（`set -eu`）。
- 该 keystore 仅供内部/测试，不可用于商店发布；泄漏口令不影响正式签名。
