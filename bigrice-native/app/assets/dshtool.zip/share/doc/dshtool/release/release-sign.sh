#!/system/bin/sh
# dshtool release APK 签名（apksigner v2/v3）。
# 用法：bash packaging/release-sign.sh <unsigned.apk> <out.apk>
# 环境变量（均有默认值）：
#   DSHTOOL_KS           keystore 路径（默认 packaging/release/dshtool-release.keystore）
#   DSHTOOL_KS_PASS      keystore/key 口令（默认 dshtool-release）
#   DSHTOOL_KEY_ALIAS    key alias（默认 dshtool）
#   ANDROID_BUILD_TOOLS  build-tools 目录（含 apksigner；默认自动探测）
#   APKSIGNER            直接指定 apksigner
# 成功 exit 0 且 <out.apk> 存在；失败非零。口令通过 env: 传给 apksigner，不出现在命令行。
set -eu
[ $# -eq 2 ] || { echo "usage: $0 <unsigned.apk> <out.apk>" >&2; exit 2; }
IN=$1
OUT=$2
[ -f "$IN" ] || { echo "release-sign: input not found: $IN" >&2; exit 1; }
ROOT=$(cd "$(dirname "$0")/.." && pwd)
KS=${DSHTOOL_KS:-$ROOT/packaging/release/dshtool-release.keystore}
ALIAS=${DSHTOOL_KEY_ALIAS:-dshtool}
KS_PASS=${DSHTOOL_KS_PASS:-dshtool-release}
[ -f "$KS" ] || { echo "release-sign: keystore not found: $KS" >&2; exit 1; }

APK_SIGNER=${APKSIGNER:-}
if [ -z "$APK_SIGNER" ]; then
  if [ -n "${ANDROID_BUILD_TOOLS:-}" ] && [ -x "$ANDROID_BUILD_TOOLS/apksigner" ]; then
    APK_SIGNER=$ANDROID_BUILD_TOOLS/apksigner
  else
    APK_SIGNER=$(command -v apksigner 2>/dev/null || true)
  fi
fi
if [ -z "$APK_SIGNER" ]; then
  for cand in "$ROOT/.work/tooling/sdk/build-tools"/*/apksigner "$HOME/Android/Sdk/build-tools"/*/apksigner; do
    [ -x "$cand" ] && { APK_SIGNER=$cand; break; }
  done
fi
[ -n "$APK_SIGNER" ] && [ -x "$APK_SIGNER" ] || { echo "release-sign: apksigner not found (set APKSIGNER/ANDROID_BUILD_TOOLS)" >&2; exit 1; }

# apksigner 是 Java 工具：宿主上若 java 不在 PATH，尝试仓库自带 JDK。
if ! command -v java >/dev/null 2>&1; then
  for jdk in "$ROOT/.work/tooling/jdk/bin" "$ROOT/.work/tooling/jdk"/*/bin; do
    [ -x "$jdk/java" ] && { PATH="$jdk:$PATH"; export PATH; break; }
  done
fi
command -v java >/dev/null 2>&1 || { echo "release-sign: java not found (set JAVA_HOME/PATH)" >&2; exit 1; }

TMP=$(mktemp "${TMPDIR:-/tmp}/dshtool-sign.XXXXXX")
trap 'rm -f "$TMP"' EXIT INT TERM
cp "$IN" "$TMP"
export DSHTOOL_KS_PASS="$KS_PASS"
echo "release-sign: signing $IN with $(basename "$APK_SIGNER") alias=$ALIAS" >&2
"$APK_SIGNER" sign \
  --ks "$KS" --ks-pass env:DSHTOOL_KS_PASS --key-pass env:DSHTOOL_KS_PASS \
  --ks-key-alias "$ALIAS" --min-sdk-version 24 \
  --v1-signing-enabled false --v2-signing-enabled true --v3-signing-enabled true \
  "$TMP"
"$APK_SIGNER" verify --min-sdk-version 24 --print-certs "$TMP" >&2
mkdir -p "$(dirname "$OUT")"
mv "$TMP" "$OUT"
trap - EXIT INT TERM
echo "release-sign: ok $OUT ($(wc -c < "$OUT") bytes)" >&2
