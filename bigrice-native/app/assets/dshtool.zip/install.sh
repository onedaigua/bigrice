#!/system/bin/sh
# 把 dshtool 安装到 $PREFIX（默认 ~/.local）。只在 Android 设备上运行。
set -e
HERE=$(cd "$(dirname "$0")" && pwd)
PREFIX=${PREFIX:-$HOME/.local}
mkdir -p "$PREFIX/bin" "$PREFIX/lib"
cp -a "$HERE/bin/." "$PREFIX/bin/"
cp -a "$HERE/lib/." "$PREFIX/lib/"
ln -sf "$PREFIX/bin/dshtool" "$PREFIX/bin/dsh"
ln -sf "$PREFIX/bin/dshtool" "$PREFIX/bin/dsh"
echo "installed: $PREFIX/bin/dshtool (also linked as dsh)"
echo "run: dshtool web --host 127.0.0.1 --port 0 --no-open"
